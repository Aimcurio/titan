from pathlib import Path
import subprocess, json, os, sys, hashlib, time
c=Path(__file__).resolve().parent
repos=c/'repos'
out=c/'evidence/independent-bounded-flight'
out.mkdir()
env=dict(os.environ,TEMP=str(c/'tmp'),TMP=str(c/'tmp'),TMPDIR=str(c/'tmp'))
loader=repos/'spc-remediation/node_modules/tsx/dist/loader.mjs'
spc=['node','--import',str(loader),str(repos/'spc-remediation/src/cli.ts')]
oracle=['node','--import',str(loader),str(repos/'ruleforge-engine/src/cli/oracle-cli.ts')]
ef=str(c/'build/evidence-forge/debug/evidence-forge')
fr=str(c/'build/flight-recorder/debug/flight-recorder')
records=[]
def run(name,args,success=True):
    p=subprocess.run([str(a) for a in args],cwd=repos/'ruleforge-engine',env=env,capture_output=True,timeout=60)
    (out/(name+'.stdout')).write_bytes(p.stdout)
    (out/(name+'.stderr')).write_bytes(p.stderr)
    r={'name':name,'argv':[str(a) for a in args],'cwd':str(repos/'ruleforge-engine'),'exit':p.returncode,'expected_success':success}
    records.append(r);(out/'commands.json').write_text(json.dumps(records,indent=2))
    assert (p.returncode==0)==success,r
    return p.stdout.decode()
revision=run('revision',['git','rev-parse','HEAD']).strip()
request={'interopVersion':'1.0.0','projectIdentity':{'projectId':'independent-ruleforge-flight','projectName':'RuleForge simulation engine','commitSha':revision},'executionIntent':'Verify deterministic simulation replay and invariant preservation with bounded local tests. No deployment or promotion.'}
(out/'request.json').write_text(json.dumps(request))
contract=json.loads(run('preflight',spc+['titan-compile',out/'request.json']))
assert contract['success'] and not contract['contract']['authorityEnvelope']['canPromoteToProduction']
assert contract['contract']['identity']['commitSha']==revision
args=oracle[1:]+['run','--target','ruleforge','--seed','1337','--steps','12','--out',str(out/'oracle'),'--json']
cfg=out/'oracle.toml'
cfg.write_text('name="independent bounded flight"\n[[steps]]\nid="execute"\ncommand="node"\nargs='+json.dumps(args)+'\ntimeout_secs=30\n')
run('execute',[ef,'run',repos/'ruleforge-engine','--config',cfg,'--output',out/'package','--strict'])
run('verify',[ef,'verify',out/'package'])
report=json.loads((out/'oracle/report.json').read_text())
assert report['verdict']=='PASS' and report['totalTransitionsAudited']>0
run('oracle-package',oracle+['verify-package',out/'oracle'])
run('replay',oracle+['replay','--target','ruleforge','--seed','1337'])
run('resume',oracle+['resume','--target','ruleforge','--seed','1337'])
(out/'package/evidence.json').write_text('{}')
run('corrupt-rejected',[ef,'verify',out/'package'],False)
run('recorder-init',[fr,'init','--dir',out/'recorder','--project','independent-ruleforge-flight','--repo-path',repos/'ruleforge-engine','--tester','Independent verifier','--objective','Bounded companion exchange only; no operational Titan authority'])
run('recorder-artifact',[fr,'artifact','--dir',out/'recorder','--file',out/'oracle/report.json','--label','Actual Oracle execution','--kind','diagnostic-output'])
run('recorder-error',[fr,'event','--dir',out/'recorder','--kind','error','--provenance','machine','--description','Corrupt evidence package rejected during independent probe'])
run('recorder-complete',[fr,'complete','--dir',out/'recorder','--outcome','Bounded probe completed with deliberately corrupted package'])
run('recorder-export',[fr,'export-titan','--dir',out/'recorder','--output',out/'packet.json'])
packet=json.loads((out/'packet.json').read_text())
assert packet['typed_status']=='completed_with_defects' and packet['release_promotion_authorized'] is False
(out/'summary.json').write_text(json.dumps({'bounded_exchange':'PASS','commands':len(records),'subject_revision':revision,'full_five_tool_integration':'BLOCKED','release':'NOT RELEASE QUALIFIED','adaptations':['Node --import tsx loader instead of tsx CLI IPC','native Linux binary paths'],'source_modified':False},indent=2))
print('Bounded exchange passed:',len(records),'commands; full workflow remains BLOCKED')
