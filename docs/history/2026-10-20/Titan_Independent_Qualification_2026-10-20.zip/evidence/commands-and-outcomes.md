# Commands and outcome map

All commands ran in isolated verification checkouts. Rust 1.97.1 was installed under the scratch workspace; RUSTUP_HOME/CARGO_HOME point there. Cargo targets, TMP and evidence were external. No source edits or assertion changes.

| Check | Command | Exit / evidence |
|---|---|---|
| Remote identity | git ls-remote https://github.com/Aimcurio/titan.git | 0; publication-identity.log |
| Object validity | git -C titan-review fsck --full --strict | 0; publication-identity.log |
| Clean SPC install | npm ci --prefix qualification-run/repos/spc-remediation --cache <workspace>/npm-cache --no-audit --no-fund | 0; spc-npm-ci.log |
| Independent Titan suite | cargo test --manifest-path qualification-run/repos/titan-forward/Cargo.toml --locked --offline --no-fail-fast --target-dir <campaign>/build/titan-forward | 101; titan-independent.log |
| Aggregate entry point | python3 -X utf8 qualification-run/repos/titan-forward/tools/verify_all.py | 1; aggregate-independent.log and *-frozen-selftest.log |
| Original flight entry point | python3 -X utf8 qualification-run/repos/titan-forward/tools/tool_flight.py | 1 at SPC launch; original-tool-flight-independent.log |
| TypeScript assertions via module loader | node --import <SPC>/node_modules/tsx/dist/loader.mjs <script> [test:all] | all four 0; typescript-loader-independent.json has exact argv/cwd |
| Companion Rust tests | cargo test --locked --offline --no-fail-fast --target-dir <campaign>/build/<component> | Evidence Forge 101; Learning Trace 0; Flight Recorder 0; rust-companion-independent.json |
| Format | cargo fmt --all -- --check | 1; titan-fmt.log |
| Clippy | cargo clippy --locked --offline --all-targets --target-dir <campaign>/build/titan-forward -- -D warnings | 101; titan-clippy.log |
| Fresh F04 confirmation | cargo test --locked --offline --manifest-path <Titan>/Cargo.toml --target-dir <campaign>/build/f04-confirmation --test a04 a04_guard_fixture_root_and_real_reparse_if_supported -- --exact | 101; f04-hardlink-confirmation.log |
| F06 serial diagnostic | cargo test --locked --offline --manifest-path <Titan>/Cargo.toml --target-dir <campaign>/build/titan-forward --test a06 -- --test-threads=1 | 101; 52/1; a06-serial-diagnostic.log |
| F06 isolated serial diagnostic | cargo test --locked --offline --manifest-path <Titan>/Cargo.toml --target-dir <campaign>/build/a06-isolated --test a06 -- --test-threads=1 | 101; 51/2; a06-isolated-serial.log |
| External adversarial probes | cargo run --offline --manifest-path qualification-run/probes/Cargo.toml --target-dir <campaign>/build/probes -- <campaign>/evidence/adversarial-probe-output | 0; adversarial-probes.log, source under probes/ |
| Independent bounded exchange | python3 qualification-run/bounded-flight.py | 0; bounded-flight-driver.log; independent-bounded-flight/commands.json |

The aggregate run repeated Titan on retained build fixtures. Its 265/20 result includes the confirmed A03 existing-symlink failure and F06 directory-metadata mismatches. It is not a fresh-build count and does not replace the first 283/2 result. Diagnostics are explicitly partial/focused and never replace the failed full gate.
