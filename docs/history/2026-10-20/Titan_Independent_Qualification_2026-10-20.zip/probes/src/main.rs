use flight_recorder::{Session, ArtifactRegistry, ArtifactKind, TitanAdapter, IntegrityValidator};
use std::{path::PathBuf, time::{Duration, Instant}};

fn main() {
    let root=PathBuf::from(std::env::args().nth(1).expect("external probe root"));
    std::fs::create_dir_all(&root).unwrap();
    let mut session=Session::init(root.join("session"),"independent-probe","fixture",None,"1","verifier","stale artifact writers",vec![],vec![]).unwrap();
    let mut first=ArtifactRegistry::load(&session.dir).unwrap();
    let mut stale=ArtifactRegistry::load(&session.dir).unwrap();
    let a=first.register_bytes(&session.dir,b"first evidence","first.txt","first",ArtifactKind::Log).unwrap();
    let b=stale.register_bytes(&session.dir,b"second evidence","second.txt","second",ArtifactKind::Log).unwrap();
    let loaded=ArtifactRegistry::load(&session.dir).unwrap();
    session.complete(Some("probe finished")).unwrap();
    let exported=TitanAdapter::export(&session,true);
    println!("{}",serde_json::json!({"probe":"stale-artifact-registry","successful_captures":2,"persisted_registry_count":loaded.artifacts.len(),"first_registered":loaded.artifacts.iter().any(|v|v.id==a.id),"second_registered":loaded.artifacts.iter().any(|v|v.id==b.id),"first_file_exists":session.dir.join(&a.stored_relative_path).is_file(),"integrity_valid":IntegrityValidator::validate_session_dir(&session.dir).unwrap().is_valid,"export_status":exported.typed_status,"release_promotion_authorized":exported.release_promotion_authorized}));
    let subject=root.join("process-subject"); std::fs::create_dir(&subject).unwrap();
    let sentinel=root.join("descendant-survived.txt");
    let child=format!("import time,pathlib;time.sleep(1.6);pathlib.Path({:?}).write_text('survived')",sentinel.to_str().unwrap());
    let parent=format!("import subprocess;subprocess.Popen(['python3','-c',{:?}])",child);
    let cfg=format!("name='descendant-probe'\n[[steps]]\nid='spawn'\ncommand='python3'\nargs=['-c',{}]\ntimeout_secs=1\n",serde_json::to_string(&parent).unwrap());
    let config=evidence_forge::config::EvidenceForgeConfig::load_from_str(&cfg).unwrap();
    let start=Instant::now();let result=evidence_forge::execution::execute_step(&subject,&config.steps[0]);let elapsed=start.elapsed().as_millis();
    std::thread::sleep(Duration::from_millis(900));
    println!("{}",serde_json::json!({"probe":"descendant-containment","return_ms":elapsed,"execution_error":result.err().map(|e|e.to_string()),"descendant_wrote_after_return":sentinel.is_file()}));
}
